<?php
    $host = "localhost";
    $user = "root";
    $key = "";
    $db = "elarrastre";

    $con = mysqli_connect($host, $user, $key, $db);
?>