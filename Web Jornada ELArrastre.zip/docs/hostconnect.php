<?php
    $host = "localhost";
    $user = "root";
    $key = "";
    $db = "elarrastre";

    //$host = "localhost";
    //$user = "bcolyvok_ELArrastre";
    //$key = "l97f6e61m";
    //$db = "bcolyvok_ELArrastre";

    //$host = "localhost";
    //$user = "u463589001_user4t";
    //$key = "Elarrastre-1";
    //$db = "u463589001_elarrastre";


    $con = mysqli_connect($host, $user, $key, $db);
?>