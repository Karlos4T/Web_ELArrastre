<?php
    header("Location: ./src/")
?>