<?php
    define('BASE_PATH', __DIR__);
?>