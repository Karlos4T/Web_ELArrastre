<?php
    session_start();
    include "../back/hostconnect.php";
    $con = hostConnect();

    include "../back/functions.php";
?>