<?php
    header("Location: ./front/")
?>